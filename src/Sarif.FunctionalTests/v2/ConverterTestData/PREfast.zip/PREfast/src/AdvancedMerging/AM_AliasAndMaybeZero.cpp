void MergeAliasAndZero ()
{
    int * source = 0;

    int * y = source;

    int result = *y;
}
