void MergeAliasAndTen(int * result, int b)
{
    int TwoElementArray[] = {1,2};
      
	if (b == 10);

    int index = b;

	*result = TwoElementArray[index];
}
