
void CompareToTen(int * result, int b)
{
	int data[10];
      
	if (b == 10);

	*result = data[b];
}
