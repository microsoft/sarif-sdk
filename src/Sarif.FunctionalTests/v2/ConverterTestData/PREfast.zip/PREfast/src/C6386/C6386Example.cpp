void C6386_Example()
{
   char a[4];
   int j = 4;
   if( j < 4)
   {
      a[j] = 'a';
   }
      a[j] = '\0';
}

