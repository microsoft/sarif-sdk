#pragma warning (disable : 4701)
int C6001_Example1 ( bool b, bool c)
{
   int i;
   if ( b && c)
   {
      i = 0;
   }
   return i; 
}
