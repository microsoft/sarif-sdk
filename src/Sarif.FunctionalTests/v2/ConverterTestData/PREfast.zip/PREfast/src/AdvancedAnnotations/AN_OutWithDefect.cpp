
#include <sal.h>

void Out6101(_Out_ int * target, bool flag)
{
    if (flag)
        *target = 10;
}
