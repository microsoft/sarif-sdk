void C6385_Example(int i)
{
   char a[5];
   for (int j=0; j<5; j++) a[j] = 5;
   char k;
   if (i <= 5)
   {
      k = a[i];
   }
}
