void C6386_Example2(int i)
{
   int a[20];				
   int j = 1;
   if (i <= 21)				
   {
      a[i-1] = j;			
   }
}