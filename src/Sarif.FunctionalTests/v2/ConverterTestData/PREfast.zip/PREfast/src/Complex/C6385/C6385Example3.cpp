#pragma warning (disable : 6001)
void C6385_Example3(int i)
{
   int a[20];				
   int j;
   i=20;
   if (i >= 0 && i <= 20)	
   {
      j = a[i];			
   }
}