void C6386_Example(int i)
{
   char a[4];
   for(i; i < 4; i++)
   {
      a[i] = 'a';
   }
      a[i] = '\0';
}
