
void RemoteFunction(int* x);

void RemoteFunction(int* x, int* y);
